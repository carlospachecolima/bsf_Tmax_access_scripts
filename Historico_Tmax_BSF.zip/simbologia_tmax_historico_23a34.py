
from qgis.core import (
    QgsProject,
    QgsColorRampShader,
    QgsRasterShader,
    QgsSingleBandPseudoColorRenderer
)
from PyQt5.QtGui import QColor

# Faixa para Tmax Histórico (ºC)
min_temp = 23.0
max_temp = 34.0

# Paleta para Tmax histórico (23 a 34 ºC)
cores_tmax_historico = [
    (23.0, QColor("#0000ff")),
    (25.0, QColor("#005fff")),
    (27.0, QColor("#00bfff")),
    (29.0, QColor("#00ffff")),
    (31.0, QColor("#80ff80")),
    (33.0, QColor("#ffff00")),
    (34.0, QColor("#ff9900"))
]

# Aplicar simbologia às camadas de Temperatura máxima histórica
for layer in QgsProject.instance().mapLayers().values():
    if layer.type() == layer.RasterLayer and "temperatura máxima histórica" in layer.name().lower():
        print(f"🎨 Estilizando: {layer.name()}")

        shader_items = []
        for valor, cor in cores_tmax_historico:
            shader_items.append(QgsColorRampShader.ColorRampItem(valor, cor, f"{valor:.1f} °C"))

        shader = QgsColorRampShader()
        shader.setColorRampType(QgsColorRampShader.Interpolated)
        shader.setColorRampItemList(shader_items)
        shader.setMinimumValue(min_temp)
        shader.setMaximumValue(max_temp)

        raster_shader = QgsRasterShader()
        raster_shader.setRasterShaderFunction(shader)

        renderer = QgsSingleBandPseudoColorRenderer(layer.dataProvider(), 1, raster_shader)
        layer.setRenderer(renderer)
        layer.triggerRepaint()

        print(f"✅ Estilo aplicado a: {layer.name()}")

print("🎯 Estilização concluída para Temperatura máxima histórica.")

# --- Salvar o projeto ---
caminho_projeto = "E:/Projeto GeoBSF/Access/Tmax/Historico/Tmax_Historico.qgz"
if QgsProject.instance().write(caminho_projeto):
    print(f"💾 Projeto salvo com sucesso em: {caminho_projeto}")
else:
    print(f"⚠️ Erro ao salvar o projeto em: {caminho_projeto}")
