from qgis.core import (
    QgsProject,
    QgsColorRampShader,
    QgsRasterShader,
    QgsSingleBandPseudoColorRenderer
)
from PyQt5.QtGui import QColor

min_temp = 23.0
max_temp = 36.0

cores_tmax = [
    (23.0, QColor("#0000ff")),
    (25.0, QColor("#005fff")),
    (27.0, QColor("#00bfff")),
    (29.0, QColor("#00ffff")),
    (31.0, QColor("#80ff80")),
    (33.0, QColor("#ffff00")),
    (35.0, QColor("#ff9900")),
    (36.0, QColor("#ff3300"))
]

for layer in QgsProject.instance().mapLayers().values():
    if layer.type() == layer.RasterLayer:
        print(f"🎨 Estilizando: {layer.name()}")
        shader_items = [QgsColorRampShader.ColorRampItem(valor, cor, f"{valor:.1f} °C") for valor, cor in cores_tmax]
        shader = QgsColorRampShader()
        shader.setColorRampType(QgsColorRampShader.Interpolated)
        shader.setColorRampItemList(shader_items)
        shader.setMinimumValue(min_temp)
        shader.setMaximumValue(max_temp)
        raster_shader = QgsRasterShader()
        raster_shader.setRasterShaderFunction(shader)
        renderer = QgsSingleBandPseudoColorRenderer(layer.dataProvider(), 1, raster_shader)
        layer.setRenderer(renderer)
        layer.triggerRepaint()
        print(f"✅ Estilo aplicado a: {layer.name()}")

print("🎯 Estilização concluída para Temperatura máxima – SSP370 (2061–2080).")
