from qgis.core import QgsProject

meses = ['jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez']

layers = QgsProject.instance().mapLayers().values()
for layer in layers:
    for mes in meses:
        if mes in layer.name():
            layer.setName(f"Temperatura máxima (ºC)_{mes}")
            print(f"✅ Camada renomeada para: Temperatura máxima (ºC)_{mes}")
