from qgis.core import (
    QgsProject, QgsLayoutExporter, QgsPrintLayout,
    QgsLayoutItemMap, QgsLayoutItemLabel, QgsReadWriteContext
)
from qgis.PyQt.QtXml import QDomDocument
import os

# Caminho do template do layout (.qpt)
caminho_template = r"E:/Projeto GeoBSF/Access/Tmax/2021 a 2040/SSP245/Modelo Tmax BSF.qpt"

# Diretório de saída dos PNGs
saida_layouts = r"E:/Projeto GeoBSF/Access/Tmax/2021 a 2040/SSP126/Layouts"
os.makedirs(saida_layouts, exist_ok=True)

# Meses por extenso
meses_extenso = {
    "jan": "janeiro", "fev": "fevereiro", "mar": "março", "abr": "abril",
    "mai": "maio", "jun": "junho", "jul": "julho", "ago": "agosto",
    "set": "setembro", "out": "outubro", "nov": "novembro", "dez": "dezembro"
}

# Iterar sobre as camadas
layers = list(QgsProject.instance().mapLayers().values())

for layer in layers:
    if layer.type() == layer.RasterLayer and layer.name().startswith("Temperatura máxima (ºC)_"):
        # Extrair o mês
        mes_abrev = layer.name().split("_")[-1]
        mes_nome = meses_extenso.get(mes_abrev, mes_abrev)

        print(f"🗺️ Gerando layout para: {layer.name()}")

        # Carregar template
        project = QgsProject.instance()
        manager = project.layoutManager()
        layout = QgsPrintLayout(project)
        layout.initializeDefaults()
        doc = QDomDocument()
        with open(caminho_template, 'r', encoding='utf-8') as f:
            content = f.read()
        doc.setContent(content)
        layout.readLayoutXml(doc.documentElement(), doc, QgsReadWriteContext())
        layout.setName(f"Layout_Tmax_SSP126_2021_2040_{mes_abrev}")

        # Adicionar layout ao gerenciador
        manager.addLayout(layout)

        # Atualizar o título
        for item in layout.items():
            if isinstance(item, QgsLayoutItemLabel):
                if "Temperatura máxima" in item.text() or "Temperatura mínima" in item.text() or "Precipitação" in item.text():
                    novo_titulo = f"Temperatura máxima projetada para o mês de {mes_nome} para o período entre 2021 a 2040 no cenário SSP126 para a região do Baixo São Francisco"
                    item.setText(novo_titulo)
                    item.refresh()

        # Atualizar o mapa
        for item in layout.items():
            if isinstance(item, QgsLayoutItemMap):
                item.setLayers([layer])
                item.zoomToExtent(layer.extent())
                item.refresh()

        # Exportar o layout
        nome_arquivo = f"Tmax_SSP126_2021_2040_{mes_abrev}.png"
        caminho_saida = os.path.join(saida_layouts, nome_arquivo)

        exporter = QgsLayoutExporter(layout)
        settings = QgsLayoutExporter.ImageExportSettings()
        result = exporter.exportToImage(caminho_saida, settings)

        if result == QgsLayoutExporter.Success:
            print(f"✅ Layout salvo em: {caminho_saida}")
        else:
            print(f"⚠️ Falha ao exportar: {caminho_saida}")

print("🎯 Layouts finalizados para Temperatura máxima - SSP126 - 2021 a 2040!")
