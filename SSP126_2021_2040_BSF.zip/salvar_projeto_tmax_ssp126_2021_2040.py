import os
from qgis.core import QgsProject

caminho_projeto = r"E:/Projeto GeoBSF/Access/Tmax/2021 a 2040/SSP126/Tmax_SSP126_2021_2040.qgz"

os.makedirs(os.path.dirname(caminho_projeto), exist_ok=True)

if QgsProject.instance().write(caminho_projeto):
    print(f"💾 Projeto salvo com sucesso em: {caminho_projeto}")
else:
    print(f"⚠️ Erro ao salvar o projeto em: {caminho_projeto}")
